﻿/* Тип входных данных:
 * ПервоеЧисло_РазрядПервогоЧисла_АрифметическоеДействие_ВтороеЧисло_РазрядПервогоЧисла
 * Пример:
 * 10010 2 + 57 9
 * + Разряд выходного числа, Пример:
 * 10
 * Для завершения цикла введите вместо выражения "0"
 */
using System;
using System.Collections.Generic;
namespace Universe_Summ{
    class Program{
        static void Main(){
            while (true){
                char[] abc = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
                int[] numz = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35 };
                int raz, term1 = 0, term2 = 0;
                Console.WriteLine("Напиши уравнение:");
                string cin = Console.ReadLine();
                if(cin == "0"){
                    break;
                }
                string[] data = cin.Split(' ');
                Console.WriteLine("Напиши разряд выходного числа:");
                raz = Convert.ToInt32(Console.ReadLine());
                if (raz <= 36){
                    char[] num_1 = data[0].ToCharArray();
                    char[] num_2 = data[3].ToCharArray();
                    //перевод первого числа в 10-тичную систему
                    for (int i = 0; i < num_1.Length; i++){
                        int steppe_1 = Convert.ToInt32(Math.Pow(Convert.ToInt32(data[1]), i));
                        for (int g = 0; g < abc.Length; g++){
                            if (num_1[i] == abc[g]){
                                if (Convert.ToInt32(abc[g]) >= Convert.ToInt32(data[1])){
                                    Console.WriteLine("Цифра не подходит под систему счисления!");
                                    break;
                                }
                                else
                                    term1 += numz[g] * steppe_1;
                            }
                        }
                    }
                    //перевод второго числа в 10-тичную систему
                    for (int j = 0; j < num_2.Length; j++){
                        int steppe_2 = Convert.ToInt32(Math.Pow(Convert.ToInt32(data[4]), j));
                        for (int g = 0; g < abc.Length; g++){
                            if (num_2[j] == abc[g]){
                                if (Convert.ToInt32(abc[g]) >= Convert.ToInt32(data[4])){
                                    Console.WriteLine("Цифра не подходит под систему счисления!");
                                    break;
                                }
                                else
                                    term2 += numz[g] * steppe_2;
                            }
                        }
                    }
                    int rez = 0;
                    //разпознование ариф. действия
                    switch (data[2]){
                        case "+":
                            rez = term1 + term2;
                            break;
                        case "-":
                            rez = term1 - term2;
                            break;
                        case "*":
                            rez = term1 * term2;
                            break;
                        case "/":
                            try { 
                                rez = term1 / term2; 
                            }
                            catch (DivideByZeroException){
                                Console.WriteLine("Деление на ноль");
                            }
                            break;
                        default:
                            Console.WriteLine("Недопустимый символ!");
                            break;
                    }
                    Console.WriteLine(rez);
                    List<int> nums = new();
                    //перевод результата в нужную систему
                    while (rez > 0){
                        nums.Add(rez % raz);
                        rez /= raz;
                    }
                    nums.Reverse();
                    int[] Nums = nums.ToArray();
                    List<char> Rez = new();
                    for (int u = 0; u < Nums.Length; u++){
                        for (int g = 0; g < abc.Length; g++){
                            if (Nums[u] == numz[g])
                                Rez.Add(abc[g]);
                        }
                    }
                    //вывод результата
                    Console.WriteLine("Результат:");
                    foreach (char el in Rez)
                        Console.Write(el);
                    if(Rez.Count == 0)
                        Console.WriteLine("0");
                    Console.WriteLine(" ");
                }
                else
                    Console.WriteLine("Неправильный разряд");
            }
        }
    }
}